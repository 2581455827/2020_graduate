#ifndef __VARIABLE_H__
#define __VARIABLE_H__

#include"iocc2530.h"
#define uint unsigned int 
#define uchar unsigned char

#define IC_CS   P2_0
#define IC_SCK  P0_7
#define IC_MOSI P0_6
#define IC_MISO P0_5
#define IC_REST P0_4
#endif