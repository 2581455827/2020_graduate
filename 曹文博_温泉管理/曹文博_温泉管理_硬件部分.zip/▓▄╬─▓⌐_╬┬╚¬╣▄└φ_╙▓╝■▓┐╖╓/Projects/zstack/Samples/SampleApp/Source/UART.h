#ifndef __UART_H__
#define __UART_H__

extern void UartInitial(void);
extern void UartSend(unsigned char infor);

#endif